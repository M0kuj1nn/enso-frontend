'use client';

import { FC, memo } from 'react';

import { useChatContext } from '@contexts/ChatContext';
import { Container } from '@ui/Container';
import { Text } from '@ui/typography/Text';

import { VoiceConferenceHeader } from './VoiceConferenceHeader';

interface VoiceConferenceProps {
  channelId: string;
  serverId: string;
}

export const VoiceConference: FC<VoiceConferenceProps> = memo(({ channelId, serverId }) => {
  const { servers, participants, leaveVoiceChannel } = useChatContext();

  const server = servers.find((s) => s.id === serverId);
  const channel = server?.voice_channels.find((c) => c.id === channelId);

  const allUsers = Object.values(participants)
    .flat()
    .filter((u, i, arr) => arr.findIndex((x) => x.id === u.id) === i);

  const voiceParticipants = (channel?.participants ?? [])
    .map((p) => ({
      user: allUsers.find((u) => u.id === p.userId),
      isSpeaking: p.isSpeaking,
    }))
    .filter((p) => p.user != null) as { user: (typeof allUsers)[0]; isSpeaking: boolean }[];

  if (!channel) {
    return (
      <Container className='flex-1 items-center justify-center'>
        <Text variantsUi={{ color: 'muted' }}>Канал не найден</Text>
      </Container>
    );
  }

  const N = voiceParticipants.length;

  return (
    <Container variantsUi={{ flow: 'col' }} className='h-full flex-1 gap-0 p-0'>
      <VoiceConferenceHeader
        channelName={channel.name}
        participantCount={N}
        onLeave={leaveVoiceChannel}
      />

      <Container className='flex-1 items-center justify-center gap-0 p-8'>
        {N === 0 ? (
          <Text variantsUi={{ color: 'muted' }}>Никого нет в канале</Text>
        ) : (
          <div className='flex items-end justify-center gap-12'>
            {voiceParticipants.map(({ user, isSpeaking }, i) => {
              const center = (N - 1) / 2;
              // Полукруг: крайние выше, центральный ниже
              const offset = Math.pow(Math.abs(i - center), 1.5) * 50;

              return (
                <div
                  key={user.id}
                  className='flex flex-col items-center gap-4 transition-transform duration-300'
                  style={{ transform: `translateY(${offset}px)` }}
                >
                  <div
                    className={[
                      'h-32 w-32 overflow-hidden rounded-full transition-all duration-300',
                      isSpeaking
                        ? 'ring-4 ring-emerald-400 ring-offset-4 ring-offset-[#141418]'
                        : 'ring-2 ring-white/10 ring-offset-2 ring-offset-[#141418]',
                    ].join(' ')}
                  >
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className='h-full w-full object-cover'
                    />
                  </div>

                  <Text variantsUi={{ size: 'sm' }} className='text-white/80'>
                    {user.name}
                  </Text>
                </div>
              );
            })}
          </div>
        )}
      </Container>
    </Container>
  );
});

VoiceConference.displayName = 'VoiceConference';