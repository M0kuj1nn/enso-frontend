'use client';

import { FC, memo } from 'react';

import { useChatDetailsContext } from '@contexts/ChatDetailsContext';
import { Chat, Participant } from '@shared/types/chat';
import { Avatar } from '@ui/Avatar';
import { Button } from '@ui/Button';
import { Container } from '@ui/Container';
import { Text } from '@ui/typography/Text';
import { MoreVertical, Search, Users } from 'lucide-react';
import { MonitorPlay, PhoneOff } from 'lucide-react';
import { useChatContext } from '@contexts/ChatContext';
import { useRouter } from 'next/navigation';

interface ChatHeaderProps {
  chat: Chat;
  participants: Participant[];
  isVoiceChannel?: boolean;
}

export const ChatHeader: FC<ChatHeaderProps> = memo(
  ({ chat, participants, isVoiceChannel = false }) => {
    const { openDetails } = useChatDetailsContext();
    const { activeVoiceChannelId, leaveVoiceChannel, servers } = useChatContext();
    const router = useRouter();

    const isJoined = activeVoiceChannelId === chat.id;

    if (isVoiceChannel) {
      return (
        <Container className='w-full shrink-0 p-0 px-6 py-3'>
          <Container
            variantsUi={{ style: 'whiteglass', rounded: 'full' }}
            className='w-full gap-3 bg-[#25252c]/80 px-4 py-2'
          >
            {/* Мигающий кружок если подключён, статичный если нет */}
            <span className='relative flex h-3 w-3 shrink-0'>
              {isJoined && (
                <span className='absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60' />
              )}
              <span className={[
                'relative inline-flex h-3 w-3 rounded-full',
                isJoined ? 'bg-emerald-400' : 'bg-white/20',
              ].join(' ')} />
            </span>

            <Container variantsUi={{ flow: 'col' }} className='flex-1 gap-0 p-0'>
              <Text variantsUi={{ weight: 'semibold' }}>{chat.name}</Text>
              <Container className='gap-1.5 p-0'>
                <Text variantsUi={{ size: 'xs', color: 'muted' }}>
                  {isJoined ? 'Вы подключены' : `${participants.length} участников`}
                </Text>
              </Container>
            </Container>

            <Container className='gap-1 p-0'>
              {isJoined && (
                <>
                  <Button
                    variantsUi={{ color: 'ghost', rounded: 'lg' }}
                    className='p-2'
                    title='Войти в конференцию'
                    onClick={() => {
                      const server = servers.find((s) =>
                        s.voice_channels.some((vc) => vc.id === chat.id)
                      );
                      if (server) router.push(`/chat/${server.id}/${chat.id}/voice`);
                    }}
                  >
                    <MonitorPlay className='h-5 w-5 text-emerald-400' />
                  </Button>
                </>
              )}
            </Container>
          </Container>
        </Container>
      );
    }

    return (
      <Container className='w-full shrink-0 p-0 px-6 py-3'>
        <Container
          as='header'
          variantsUi={{ style: 'whiteglass', rounded: 'full' }}
          className='group w-full cursor-pointer gap-3 bg-[#25252c]/80 px-4 py-2'
          onClick={openDetails}
        >
          <Avatar src={chat.avatar} alt={chat.name} size='md' shape='rounded' />

          <Container variantsUi={{ flow: 'col' }} className='flex-1 gap-0 p-0'>
            <Text
              variantsUi={{ weight: 'semibold' }}
              className='transition-colors group-hover:text-[#A74BE9]'
            >
              {chat.name}
            </Text>
            <Container className='gap-1.5 p-0'>
              <Users className='h-3 w-3 text-[#969696]' />
              <Text variantsUi={{ size: 'xs', color: 'muted' }}>
                {participants.length} участников
              </Text>
            </Container>
          </Container>

          <Container className='gap-1 p-0'>
            <Button
              variantsUi={{ color: 'ghost', rounded: 'lg' }}
              className='p-2'
              onClick={(e) => e.stopPropagation()}
            >
              <Search className='h-5 w-5' />
            </Button>
            <Button
              variantsUi={{ color: 'ghost', rounded: 'lg' }}
              className='p-2'
              onClick={(e) => e.stopPropagation()}
            >
              <MoreVertical className='h-5 w-5' />
            </Button>
          </Container>
        </Container>
      </Container>
    );
  },
);

ChatHeader.displayName = 'ChatHeader';
